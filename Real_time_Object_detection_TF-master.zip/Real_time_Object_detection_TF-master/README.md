# Real_time_Object_detection_TF
This is an implementation of tensor flow object detection API for running it in Real time through Webcam

The video tutorial for the same is at : https://www.youtube.com/watch?v=MoMjIwGSFVQ

Download the object_recognition_detection.zip

For running the object detection on image files run the object_detection_tutorial.py

For running the object detection in realtime with web camera run the object_detection_webcam.py

The official tensorflow object detection API link is https://github.com/tensorflow/models/tree/master/object_detection
